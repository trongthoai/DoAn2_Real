package com.example.doan2.View.TrangChu;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.doan2.R;
import com.example.doan2.View.ManHinhChao.ManHinhChaoActivity;

public class TrangChuActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trangchu_layout);

    }
}
